// ============================================================================
// PikaBot 2080 - خادم الذكاء الاصطناعي (وكيل بأدوات)
// - الوقت من ساعة الخادم، والطقس من Open-Meteo (بدون مفتاح)
// - وكيل يقرر بنفسه استخدام الأدوات:
//     خادمية: web_search (سلسلة: Google إن هُيئ، ثم SearXNG إن هُيئ، ثم Wikipedia وDuckDuckGo)
//     على الجهاز: set_alarm, set_timer, open_google_search, take_photo, track_face
// - ذاكرة دائمة لكل جهاز، تُستخلص من المحادثات، ويمكن مسحها
// - مفاتيح API تبقى على الخادم فقط
// ============================================================================

import http from "node:http";
import { timingSafeEqual } from "node:crypto";
import { readFile, writeFile, rename, mkdir } from "node:fs/promises";
import path from "node:path";

// ---------- الإعدادات ----------
const PORT = Number(process.env.PORT || 8787);
const PROVIDER = (process.env.AI_PROVIDER || "anthropic").toLowerCase();
const MODEL = process.env.AI_MODEL || (PROVIDER === "anthropic" ? "claude-haiku-5-5" : "gpt-4o-mini");
const MAX_TOKENS = Number(process.env.MAX_TOKENS || 700);
const CLIENT_TOKEN = process.env.CLIENT_TOKEN || "";
const RATE_LIMIT_PER_MIN = Number(process.env.RATE_LIMIT_PER_MIN || 20);
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
const LEARN_ENABLED = process.env.LEARN !== "0";
const DATA_DIR = process.env.DATA_DIR || "./data";
const MEMORY_FILE = path.join(DATA_DIR, "memories.json");
const MEMORY_LIMIT = 40;
const DEFAULT_TZ = process.env.DEFAULT_TIMEZONE || "Africa/Algiers";
const DEFAULT_LOCATION = { lat: 36.75, lon: 3.06, name: "الجزائر العاصمة" };
const WEATHER_BASE = process.env.WEATHER_BASE_URL || "https://api.open-meteo.com/v1/forecast";
const WEATHER_CACHE_MS = 10 * 60_000;
const ANTHROPIC_BASE = process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com";
const OPENAI_BASE = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
const GOOGLE_CSE_KEY = process.env.GOOGLE_CSE_KEY || "";
const GOOGLE_CSE_CX = process.env.GOOGLE_CSE_CX || "";
const GOOGLE_CSE_BASE = process.env.GOOGLE_CSE_BASE || "https://www.googleapis.com/customsearch/v1";
// مزودو بحث مجانيون: SearXNG تستضيفه أنت (اختياري)، وWikipedia وDuckDuckGo بلا مفتاح
const SEARXNG_URL = process.env.SEARXNG_URL || "";
const WIKI_LANG = process.env.WIKI_LANG || "ar";
const WIKI_BASE = process.env.WIKI_BASE_URL || `https://${WIKI_LANG}.wikipedia.org`;
const DDG_BASE = process.env.DDG_BASE_URL || "https://api.duckduckgo.com";
const MAX_TOOL_STEPS = 5;
const MAX_ACTIONS = 5;
const UPSTREAM_TIMEOUT_MS = 45_000;
const MAX_BODY_BYTES = 64 * 1024;
const MAX_MESSAGES = 20;
const MAX_CHARS = 2000;

if (!CLIENT_TOKEN) console.warn("تحذير: CLIENT_TOKEN فارغ. أي عميل يستطيع استخدام الخادم.");
if (!["anthropic", "openai"].includes(PROVIDER)) throw new Error(`AI_PROVIDER غير مدعوم: ${PROVIDER}`);
if (PROVIDER === "anthropic" && !process.env.ANTHROPIC_API_KEY) throw new Error("ANTHROPIC_API_KEY غير معرّف");
if (PROVIDER === "openai" && !process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY غير معرّف");
try {
  new Intl.DateTimeFormat("ar", { timeZone: DEFAULT_TZ });
} catch {
  throw new Error(`DEFAULT_TIMEZONE غير صالح: ${DEFAULT_TZ}`);
}

const BASE_PROMPT = `
أنت PikaBot 2080، روبوت مساعد ذكي يعيش على هاتف Android ويتطور مع الوقت. تتحدث بصوت مسموع، لذلك:
- أجب بالعربية الفصحى المبسطة، أو بالدارجة الجزائرية إذا تكلم المستخدم بها.
- اجعل الإجابة قصيرة (جملتان أو ثلاث) ولا تستعمل رموزاً أو قوائم.

الأدوات:
- web_search: استعملها عندما تحتاج معلومة حديثة أو حقيقة لا تعرفها بيقين (أخبار، أسعار، مواعيد، نتائج). لا تخمّن.
- set_alarm و set_timer: استعملها فقط عندما يطلب المستخدم منبهاً أو مؤقتاً.
- open_google_search: عندما يطلب المستخدم أن تفتح له بحثاً على الهاتف.
- take_photo: عندما يطلب المستخدم صورة. track_face: عندما يطلب تتبع وجهه.
- بعد استعمال أداة على الجهاز قل ما فعلته بصيغة المنجز ("ضبطت المنبه على السابعة وثلاثين")، لأن التنفيذ يتم فوراً.

الحقائق:
- الوقت والطقس المذكوران في التعليمات حقيقيان. لا تختلق أي معلومة حية غير موجودة فيهما أو لم تأتِ من web_search.
- إذا فشل البحث أو لم يكن مهيأً، قل ذلك بصراحة.
- لا تدّعِ أنك إنسان، ولا تدّعِ قدرة لم تُذكر هنا.
`.trim();

const EXTRACT_SYSTEM = `
استخرج من آخر تبادل المعلومات الدائمة والمفيدة عن المستخدم فقط: الاسم، المدينة، الاهتمامات، التفضيلات، المهنة، أهداف طويلة المدى.
تجاهل الأسئلة العابرة، والطقس، والوقت، والبحث، وكل ما ليس عن المستخدم نفسه.
لا تستخرج أي معلومة صحية أو مالية أو دينية أو سياسية أو عن الجرائم أو عن العلاقات الحساسة.
أعد مصفوفة JSON من نصوص قصيرة بصيغة الغائب، مثل ["اسمه يوسف", "يحب كرة القدم"]، أو [] إذا لم يوجد شيء.
`.trim();

// ---------- تعريف الأدوات (صيغة Anthropic) ----------
const TOOLS = [
  {
    name: "web_search",
    description: "ابحث على الويب عن معلومة حديثة أو حقيقة لا تعرفها بيقين. تعيد عناوين وروابط ومقتطفات من أول مزود يعمل.",
    input_schema: {
      type: "object",
      properties: { query: { type: "string", description: "عبارة البحث بالعربية أو الفرنسية أو الإنجليزية" } },
      required: ["query"],
    },
  },
  {
    name: "set_alarm",
    description: "اضبط منبهاً في تطبيق الساعة على الهاتف.",
    input_schema: {
      type: "object",
      properties: {
        hour: { type: "integer", minimum: 0, maximum: 23 },
        minute: { type: "integer", minimum: 0, maximum: 59 },
        label: { type: "string" },
      },
      required: ["hour", "minute"],
    },
  },
  {
    name: "set_timer",
    description: "اضبط مؤقتاً على الهاتف بعدد من الثواني.",
    input_schema: {
      type: "object",
      properties: {
        seconds: { type: "integer", minimum: 1, maximum: 86400 },
        label: { type: "string" },
      },
      required: ["seconds"],
    },
  },
  {
    name: "open_google_search",
    description: "افتح بحث Google في متصفح الهاتف ليرى المستخدم النتائج بنفسه.",
    input_schema: {
      type: "object",
      properties: { query: { type: "string" } },
      required: ["query"],
    },
  },
  {
    name: "take_photo",
    description: "افتح شاشة عين الروبوت والتقط صورة بكاميرا الهاتف الأمامية. يحفظها الهاتف في Pictures/PikaBot.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "track_face",
    description: "افتح شاشة عين الروبوت وابدأ تتبع وجه المستخدم بالكاميرا الأمامية.",
    input_schema: { type: "object", properties: {} },
  },
];

const SERVER_TOOLS = new Set(["web_search"]);

// ---------- تحديد معدل الطلبات ----------
const buckets = new Map();

function isRateLimited(key) {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || now >= bucket.resetAt) {
    buckets.set(key, { count: 1, resetAt: now + 60_000 });
    return false;
  }
  bucket.count += 1;
  return bucket.count > RATE_LIMIT_PER_MIN;
}

setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) if (now >= bucket.resetAt) buckets.delete(key);
}, 60_000).unref();

function clientKey(req) {
  if (TRUST_PROXY) {
    const forwarded = req.headers["x-forwarded-for"]?.split(",")[0]?.trim();
    if (forwarded) return forwarded;
  }
  return req.socket.remoteAddress || "unknown";
}

function isAuthorized(headerValue) {
  if (!CLIENT_TOKEN) return true;
  if (typeof headerValue !== "string") return false;
  const a = Buffer.from(headerValue);
  const b = Buffer.from(CLIENT_TOKEN);
  return a.length === b.length && timingSafeEqual(a, b);
}

function parseInstallId(value) {
  return typeof value === "string" && /^[A-Za-z0-9-]{8,64}$/.test(value) ? value : null;
}

// ---------- الموقع ----------
function parseLocation(raw) {
  const present = (v) => v !== null && v !== undefined && v !== "" && Number.isFinite(Number(v));
  if (present(raw?.lat) && present(raw?.lon)) {
    const lat = Number(raw.lat);
    const lon = Number(raw.lon);
    if (lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) return { lat, lon, name: "موقع المستخدم" };
  }
  return { ...DEFAULT_LOCATION };
}

// ---------- الوقت ----------
function localTimeText() {
  return new Intl.DateTimeFormat("ar", { timeZone: DEFAULT_TZ, dateStyle: "full", timeStyle: "short" }).format(new Date());
}

function localHour() {
  return Number(new Intl.DateTimeFormat("en-US", { timeZone: DEFAULT_TZ, hour: "numeric", hourCycle: "h23" }).format(new Date()));
}

// ---------- الطقس ----------
const WEATHER_CODES = {
  0: "صافٍ", 1: "صافٍ في الغالب", 2: "غائم جزئياً", 3: "غائم",
  45: "ضباب", 48: "ضباب كثيف",
  51: "رذاذ خفيف", 53: "رذاذ", 55: "رذاذ كثيف",
  61: "مطر خفيف", 63: "مطر", 65: "مطر غزير",
  66: "مطر متجمد خفيف", 67: "مطر متجمد",
  71: "ثلج خفيف", 73: "ثلج", 75: "ثلج كثيف",
  80: "زخات مطر خفيفة", 81: "زخات مطر", 82: "زخات مطر غزيرة",
  95: "عاصفة رعدية", 96: "عاصفة رعدية مع برد", 99: "عاصفة رعدية قوية مع برد",
};

const weatherCache = new Map();

async function getWeather(location) {
  const key = `${location.lat.toFixed(2)},${location.lon.toFixed(2)}`;
  const hit = weatherCache.get(key);
  if (hit && Date.now() - hit.at < WEATHER_CACHE_MS) return hit.data;

  const url = new URL(WEATHER_BASE);
  url.search = new URLSearchParams({
    latitude: String(location.lat),
    longitude: String(location.lon),
    current: "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m",
    timezone: "auto",
  }).toString();

  const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`weather upstream ${res.status}`);
  const current = (await res.json()).current;
  const data = {
    temperature: Math.round(current.temperature_2m),
    feelsLike: Math.round(current.apparent_temperature),
    humidity: current.relative_humidity_2m,
    precipitation: current.precipitation,
    windKmh: Math.round(current.wind_speed_10m),
    code: current.weather_code,
    description: WEATHER_CODES[current.weather_code] || "حالة جوية غير معروفة",
  };
  weatherCache.set(key, { at: Date.now(), data });
  return data;
}

function weatherAlerts(w) {
  const alerts = [];
  if (!w) return alerts;
  if (w.code >= 95) alerts.push("تحذير: عواصف رعدية الآن، ابقَ في مكان آمن.");
  else if ((w.code >= 51 && w.code <= 82) || w.precipitation > 0) {
    alerts.push(`تنبيه: ${w.description} الآن، خذ مظلة إن خرجت.`);
  }
  if (w.windKmh >= 50) alerts.push("تنبيه: رياح قوية، احذر الأشياء الخفيفة في الخارج.");
  if (w.temperature >= 40) alerts.push("تنبيه: حرارة مرتفعة جداً، اشرب الماء وابقَ في الظل.");
  if (w.temperature <= 2) alerts.push("تنبيه: برد شديد، البس ملابس دافئة.");
  return alerts;
}

// ---------- البحث على الويب: سلسلة مزودين، يُجرَّب كل واحد بالترتيب ----------
async function fetchJson(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(10_000), headers: { "user-agent": "PikaBot2080/1.0" } });
  if (!res.ok) throw new Error(`search upstream ${res.status}`);
  return res.json();
}

// Google Custom Search (مجاني حتى 100 طلب يومياً، يحتاج مفتاحاً ومحرك بحث)
async function searchGoogle(query) {
  const url = new URL(GOOGLE_CSE_BASE);
  url.search = new URLSearchParams({ key: GOOGLE_CSE_KEY, cx: GOOGLE_CSE_CX, q: query, num: "5", hl: WIKI_LANG }).toString();
  const data = await fetchJson(url);
  return (data.items || []).slice(0, 5).map((i) => ({ title: String(i.title || ""), link: String(i.link || ""), snippet: String(i.snippet || "") }));
}

// SearXNG: محرك بحث مفتوح المصدر تستضيفه بنفسك، ويجب تفعيل تنسيق json في إعداداته
async function searchSearxng(query) {
  const url = new URL("/search", SEARXNG_URL);
  url.search = new URLSearchParams({ q: query, format: "json", language: WIKI_LANG }).toString();
  const data = await fetchJson(url);
  return (data.results || []).slice(0, 5).map((r) => ({ title: String(r.title || ""), link: String(r.url || ""), snippet: String(r.content || "") }));
}

// Wikipedia: واجهة opensearch المجانية بلا مفتاح. مفيدة للمعلومات والتعريفات
async function searchWikipedia(query) {
  const url = new URL("/w/api.php", WIKI_BASE);
  url.search = new URLSearchParams({ action: "opensearch", search: query, limit: "3", format: "json", origin: "*" }).toString();
  const data = await fetchJson(url);
  const [, titles = [], descriptions = [], links = []] = data;
  return titles.map((t, i) => ({ title: String(t), link: String(links[i] || ""), snippet: String(descriptions[i] || "") }));
}

// DuckDuckGo Instant Answer: واجهة مجانية بلا مفتاح، تعطي ملخصات ومواضيع ذات صلة
async function searchDuckDuckGo(query) {
  const url = new URL("/", DDG_BASE);
  url.search = new URLSearchParams({ q: query, format: "json", no_html: "1", skip_disambig: "1" }).toString();
  const data = await fetchJson(url);
  const results = [];
  if (data.AbstractText) results.push({ title: String(data.Heading || query), link: String(data.AbstractURL || ""), snippet: String(data.AbstractText) });
  for (const topic of (data.RelatedTopics || []).slice(0, 4)) {
    if (topic.Text && topic.FirstURL) results.push({ title: String(topic.Text).slice(0, 120), link: String(topic.FirstURL), snippet: String(topic.Text) });
  }
  return results.slice(0, 5);
}

export async function webSearch(query) {
  const providers = [];
  if (GOOGLE_CSE_KEY && GOOGLE_CSE_CX) providers.push(["google", searchGoogle]);
  if (SEARXNG_URL) providers.push(["searxng", searchSearxng]);
  providers.push(["wikipedia", searchWikipedia], ["duckduckgo", searchDuckDuckGo]);
  for (const [source, search] of providers) {
    try {
      const results = (await search(query)).map((r) => ({ ...r, title: r.title.slice(0, 200), snippet: r.snippet.slice(0, 300) }));
      if (results.length) return { source, results };
    } catch (err) {
      console.error(`search provider ${source} failed:`, err.message);
    }
  }
  return { source: "none", results: [] };
}

// ---------- التحقق من مدخلات الأدوات على الجهاز ----------
function validateDeviceTool(name, input) {
  const int = (v, min, max) => Number.isInteger(v) && v >= min && v <= max;
  const text = (v, max) => (typeof v === "string" && v.trim() ? v.trim().slice(0, max) : null);
  switch (name) {
    case "set_alarm": {
      if (!int(input.hour, 0, 23) || !int(input.minute, 0, 59)) return null;
      return { hour: input.hour, minute: input.minute, label: text(input.label, 60) || "PikaBot" };
    }
    case "set_timer": {
      if (!int(input.seconds, 1, 86400)) return null;
      return { seconds: input.seconds, label: text(input.label, 60) || "PikaBot" };
    }
    case "open_google_search": {
      const query = text(input.query, 200);
      return query ? { query } : null;
    }
    case "take_photo":
    case "track_face":
      return {};
    default:
      return null;
  }
}

async function executeTool(use, actions) {
  const input = use.input && typeof use.input === "object" ? use.input : {};
  if (SERVER_TOOLS.has(use.name)) {
    const query = typeof input.query === "string" ? input.query.trim().slice(0, 200) : "";
    if (!query) return { error: "invalid_query" };
    try {
      return await webSearch(query);
    } catch {
      return { error: "search_failed" };
    }
  }
  const args = validateDeviceTool(use.name, input);
  if (!args) return { error: "invalid_or_unknown_tool" };
  if (actions.length >= MAX_ACTIONS) return { error: "too_many_actions" };
  actions.push({ type: use.name, args });
  return { status: "done_on_device" };
}

// ---------- الذاكرة ----------
let memoryStore = {};
let saveChain = Promise.resolve();
const memoryEpoch = new Map();

async function loadMemory() {
  try {
    memoryStore = JSON.parse(await readFile(MEMORY_FILE, "utf8"));
  } catch {
    memoryStore = {};
  }
}

function saveMemory() {
  saveChain = saveChain
    .then(async () => {
      await mkdir(DATA_DIR, { recursive: true });
      const tmp = `${MEMORY_FILE}.tmp`;
      await writeFile(tmp, JSON.stringify(memoryStore));
      await rename(tmp, MEMORY_FILE);
    })
    .catch((err) => console.error("memory save failed:", err.message));
  return saveChain;
}

function memoriesFor(installId) {
  return memoryStore[installId] || [];
}

function epochOf(installId) {
  return memoryEpoch.get(installId) || 0;
}

async function learnFrom(installId, messages, reply) {
  const epochAtStart = epochOf(installId);
  try {
    const transcript = [...messages, { role: "assistant", content: reply }];
    const raw = await complete({
      system: EXTRACT_SYSTEM,
      messages: [{ role: "user", content: JSON.stringify(transcript) }],
      maxTokens: 200,
    });
    const match = raw.match(/\[[\s\S]*\]/);
    if (!match) return;
    const items = JSON.parse(match[0])
      .filter((x) => typeof x === "string" && x.trim().length > 0 && x.length <= 120)
      .map((x) => x.trim());
    if (!items.length) return;
    if (epochOf(installId) !== epochAtStart) return; // مُسحت الذاكرة أثناء التعلم

    const current = [...memoriesFor(installId)];
    for (const item of items) if (!current.includes(item)) current.push(item);
    memoryStore[installId] = current.slice(-MEMORY_LIMIT);
    await saveMemory();
  } catch (err) {
    console.error("learning skipped:", err.message);
  }
}

// ---------- تعليمات النظام ----------
function buildSystemPrompt({ location, weather, memories }) {
  const lines = [BASE_PROMPT, `الوقت الحالي في ${DEFAULT_TZ}: ${localTimeText()}.`];
  if (weather) {
    lines.push(
      `الطقس الآن في ${location.name}: ${weather.description}، ${weather.temperature}°C ` +
      `(الإحساس ${weather.feelsLike}°C)، رطوبة ${weather.humidity}%، رياح ${weather.windKmh} كم/س.`
    );
  } else {
    lines.push("معلومات الطقس غير متاحة الآن، فلا تذكر الطقس.");
  }
  lines.push("أداة web_search متاحة. إذا عادت بلا نتائج فقل ذلك بصراحة ولا تخمّن.");
  if (memories.length) {
    lines.push(
      "ما تعرفه عن المستخدم من محادثات سابقة (استعمله بحذر، ولا تذكره إلا إذا كان مفيداً للسؤال):\n- " +
      memories.join("\n- ")
    );
  }
  return lines.join("\n");
}

// ---------- الاتصال بالمزودين ----------
class UpstreamError extends Error {
  constructor(status, detail) {
    super(`upstream ${status}: ${detail}`);
    this.status = status;
  }
}

async function callAnthropicRaw({ system, messages, tools, maxTokens }) {
  const body = { model: MODEL, max_tokens: maxTokens, system, messages };
  if (tools) body.tools = tools;
  const res = await fetch(`${ANTHROPIC_BASE}/v1/messages`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS),
  });
  if (!res.ok) throw new UpstreamError(res.status, await res.text());
  return res.json();
}

async function callOpenAI({ system, messages, maxTokens }) {
  const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: maxTokens,
      messages: [{ role: "system", content: system }, ...messages],
    }),
    signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS),
  });
  if (!res.ok) throw new UpstreamError(res.status, await res.text());
  const data = await res.json();
  return (data.choices?.[0]?.message?.content || "").trim();
}

// نص فقط بدون أدوات (للتعلم، ولمزود OpenAI في هذه النسخة)
async function complete({ system, messages, maxTokens = MAX_TOKENS }) {
  if (PROVIDER === "openai") return callOpenAI({ system, messages, maxTokens });
  const data = await callAnthropicRaw({ system, messages, maxTokens });
  return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("").trim();
}

// وكيل: يقرر بنفسه متى يبحث ومتى يستعمل أدوات الجهاز
async function runAgent(system, messages) {
  const convo = messages.map((m) => ({ role: m.role, content: m.content }));
  const actions = [];
  for (let step = 0; step < MAX_TOOL_STEPS; step++) {
    const data = await callAnthropicRaw({ system, messages: convo, tools: TOOLS, maxTokens: MAX_TOKENS });
    const blocks = data.content || [];
    const uses = blocks.filter((b) => b.type === "tool_use");
    if (data.stop_reason !== "tool_use" || uses.length === 0) {
      return { reply: blocks.filter((b) => b.type === "text").map((b) => b.text).join("").trim(), actions };
    }
    convo.push({ role: "assistant", content: blocks });
    const results = [];
    for (const use of uses) {
      const result = await executeTool(use, actions);
      results.push({
        type: "tool_result",
        tool_use_id: use.id,
        content: JSON.stringify(result),
        ...(result.error ? { is_error: true } : {}),
      });
    }
    convo.push({ role: "user", content: results });
  }
  return { reply: "", actions }; // تجاوز حد الخطوات
}

// ---------- التحقق من الرسائل ----------
function sanitizeMessages(raw) {
  if (!Array.isArray(raw)) return null;
  const cleaned = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") return null;
    const { role, content } = item;
    if (role !== "user" && role !== "assistant") return null;
    if (typeof content !== "string") return null;
    const text = content.trim();
    if (!text || text.length > MAX_CHARS) return null;
    cleaned.push({ role, content: text });
  }
  let trimmed = cleaned.slice(-MAX_MESSAGES);
  while (trimmed.length && trimmed[0].role !== "user") trimmed = trimmed.slice(1);
  if (!trimmed.length || trimmed[trimmed.length - 1].role !== "user") return null;
  return trimmed;
}

// ---------- أدوات HTTP ----------
function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "cache-control": "no-store",
  });
  res.end(body);
}

class PayloadError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        req.destroy();
        reject(new PayloadError("payload_too_large"));
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch {
        reject(new PayloadError("invalid_json"));
      }
    });
    req.on("error", () => reject(new PayloadError("invalid_json")));
  });
}

// ---------- المسارات ----------
async function handleChat(req, res, installId) {
  let payload;
  try {
    payload = await readJson(req);
  } catch (err) {
    return sendJson(res, err.code === "payload_too_large" ? 413 : 400, { error: err.code });
  }

  const messages = sanitizeMessages(payload?.messages);
  if (!messages) return sendJson(res, 400, { error: "invalid_messages" });

  const location = parseLocation(payload?.location);
  const weather = await getWeather(location).catch(() => null);
  const system = buildSystemPrompt({
    location,
    weather,
    memories: installId ? memoriesFor(installId) : [],
  });

  let result;
  try {
    result = PROVIDER === "anthropic"
      ? await runAgent(system, messages)
      : { reply: await complete({ system, messages, maxTokens: MAX_TOKENS }), actions: [] };
  } catch (err) {
    console.error(new Date().toISOString(), "chat upstream failure:", err.message);
    const timeout = err.name === "TimeoutError" || err.name === "AbortError";
    return sendJson(res, timeout ? 504 : 502, { error: "upstream_failed" });
  }
  if (!result.reply && result.actions.length === 0) return sendJson(res, 502, { error: "empty_reply" });

  sendJson(res, 200, { reply: result.reply, actions: result.actions });
  if (installId && LEARN_ENABLED && result.reply) void learnFrom(installId, messages, result.reply);
}

async function handleBrief(res, url) {
  const location = parseLocation({ lat: url.searchParams.get("lat"), lon: url.searchParams.get("lon") });
  const weather = await getWeather(location).catch(() => null);
  const hour = localHour();
  const greeting = hour < 12 ? "صباح الخير" : hour < 18 ? "مساء الخير" : "مساء النور";
  sendJson(res, 200, {
    greeting,
    time: localTimeText(),
    location: location.name,
    weather: weather
      ? { description: weather.description, temperature: weather.temperature, feelsLike: weather.feelsLike, windKmh: weather.windKmh }
      : null,
    alerts: weatherAlerts(weather),
  });
}

async function handleForgetMemory(res, installId) {
  if (!installId) return sendJson(res, 400, { error: "missing_install_id" });
  delete memoryStore[installId];
  memoryEpoch.set(installId, epochOf(installId) + 1);
  await saveMemory();
  return sendJson(res, 200, { ok: true });
}

// ---------- الخادم ----------
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");

    if (req.method === "GET" && url.pathname === "/health") return sendJson(res, 200, { ok: true });
    if (!isAuthorized(req.headers["x-client-token"])) return sendJson(res, 401, { error: "unauthorized" });
    if (isRateLimited(clientKey(req))) return sendJson(res, 429, { error: "rate_limited" });

    const installId = parseInstallId(req.headers["x-install-id"]);

    if (url.pathname === "/api/chat") {
      if (req.method !== "POST") return sendJson(res, 405, { error: "method_not_allowed" });
      return handleChat(req, res, installId);
    }
    if (url.pathname === "/api/brief") {
      if (req.method !== "GET") return sendJson(res, 405, { error: "method_not_allowed" });
      return handleBrief(res, url);
    }
    if (url.pathname === "/api/memory") {
      if (req.method !== "DELETE") return sendJson(res, 405, { error: "method_not_allowed" });
      return handleForgetMemory(res, installId);
    }
    return sendJson(res, 404, { error: "not_found" });
  } catch (err) {
    console.error("unhandled:", err);
    return sendJson(res, 500, { error: "internal" });
  }
});

export { server, validateDeviceTool, sanitizeMessages };

if (process.env.NODE_ENV !== "test") {
  await loadMemory();
  server.listen(PORT, () => {
    console.log(`PikaBot server on :${PORT} (provider=${PROVIDER}, model=${MODEL}, tz=${DEFAULT_TZ}, search=${SEARXNG_URL ? "searxng+" : ""}${GOOGLE_CSE_KEY ? "google+" : ""}wiki+ddg)`);
  });
}
