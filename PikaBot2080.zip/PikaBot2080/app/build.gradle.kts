plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pikabot.pikabot2080"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pikabot.pikabot2080"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "3.0.0"

        // عنوان الخادم (افتراضياً لمحاكي Android)
        buildConfigField("String", "AI_SERVER_URL", "\"http://10.0.2.2:8787/api/chat\"")
        // رمز عميل عام لتمييز التطبيق. ليس سراً، والحماية الحقيقية على الخادم.
        buildConfigField(
            "String",
            "CLIENT_TOKEN",
            "\"${project.findProperty("PIKABOT_CLIENT_TOKEN") ?: "dev-client-token"}\""
        )
    }

    buildFeatures {
        buildConfig = true
    }

    androidResources {
        // نموذج التعرف على الوجه يجب ألا يُضغط حتى يُحمَّل بالتعيين الذاكري
        noCompress += "tflite"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // CameraX: الكاميرا الأمامية والمعاينة والتقاط الصور
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")

    // ML Kit: كشف الوجوه وتتبعها على الجهاز
    implementation("com.google.mlkit:face-detection:16.1.6")

    // TensorFlow Lite: تضمين الوجه لتمييز المالك
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
}
