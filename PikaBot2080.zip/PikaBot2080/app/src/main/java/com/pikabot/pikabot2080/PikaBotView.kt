package com.pikabot.pikabot2080

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

private val COLOR_READY = Color.parseColor("#4FC3F7")
private val COLOR_LISTENING = Color.parseColor("#00E5FF")
private val COLOR_THINKING = Color.parseColor("#B388FF")
private val COLOR_SPEAKING = Color.parseColor("#80D8FF")
private val COLOR_ERROR = Color.parseColor("#FF5252")
private const val BOLT_MS = 220L

private class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val radius: Float
)

// وجه الروبوت: يرسم الشخصية ويتبع الوجه بعينيه عبر setGaze
class PikaBotView(context: Context) : View(context) {

    var state: AvatarState = AvatarState.READY
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    // اتجاه النظر المستهدف بين -1 و1، والعينان تقتربان منه بسلاسة
    private var targetGazeX = 0f
    private var targetGazeY = 0f
    private var gazeX = 0f
    private var gazeY = 0f
    private var faceVisible = false

    private val density = context.resources.displayMetrics.density
    private val startedAt = now()
    private var lastFrameAt = startedAt
    private var nextBlinkAt = 0L
    private var blinkUntil = 0L
    private var nextBoltAt = 0L
    private var boltUntil = 0L
    private var spawnAccumulator = 0f
    private val particles = ArrayList<Particle>()
    private val random = java.util.Random()
    private val headRect = RectF()
    private val boltPath = Path()
    private val mouthPath = Path()
    private var headShader: Shader? = null

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        maskFilter = BlurMaskFilter(22f * density, BlurMaskFilter.Blur.NORMAL)
    }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 3f * density
    }
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * density; strokeJoin = Paint.Join.ROUND
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null) // لوهج BlurMaskFilter
        contentDescription = context.getString(R.string.bot_name)
    }

    // x و y بين -1 و1: الموقع النسبي للوجه في الكاميرا
    fun setGaze(x: Float, y: Float) {
        targetGazeX = x.coerceIn(-1f, 1f)
        targetGazeY = y.coerceIn(-1f, 1f)
    }

    fun setFaceVisible(visible: Boolean) {
        faceVisible = visible
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        headShader = LinearGradient(
            w * 0.2f, h * 0.14f, w * 0.8f, h * 0.74f,
            intArrayOf(Color.parseColor("#1B2750"), Color.parseColor("#2C1A55")),
            null, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val t = now()
        val dt = (t - lastFrameAt).coerceIn(0L, 50L) / 1000f
        lastFrameAt = t
        val time = (t - startedAt) / 1000f
        val accent = accentColor()
        val error = state == AvatarState.ERROR

        // حركة النظر نحو الوجه بسلاسة
        gazeX += (targetGazeX - gazeX) * 0.2f
        gazeY += (targetGazeY - gazeY) * 0.2f

        val bob = if (error) 0f else sin(time * 2f) * h * 0.012f
        val shake = if (error) sin(time * 45f) * 3f * density else 0f

        headRect.set(w * 0.20f + shake, h * 0.14f + bob, w * 0.80f + shake, h * 0.74f + bob)
        val corner = w * 0.22f

        // الهوائي
        strokePaint.strokeWidth = 2f * density
        strokePaint.color = withAlpha(accent, 200)
        canvas.drawLine(w * 0.5f, h * 0.14f + bob, w * 0.5f, h * 0.04f + bob, strokePaint)
        fillPaint.color = accent
        canvas.drawCircle(w * 0.5f, h * 0.04f + bob, w * 0.035f, fillPaint)
        strokePaint.strokeWidth = 3f * density

        // الوهج
        val pulse = if (state == AvatarState.LISTENING || state == AvatarState.SPEAKING) 0.5f + 0.5f * sin(time * 6f) else 0.2f
        glowPaint.color = withAlpha(accent, (90 + 110 * pulse).toInt())
        canvas.drawRoundRect(headRect, corner, corner, glowPaint)

        headPaint.shader = headShader
        canvas.drawRoundRect(headRect, corner, corner, headPaint)
        rimPaint.color = withAlpha(accent, if (faceVisible) 255 else 200)
        canvas.drawRoundRect(headRect, corner, corner, rimPaint)

        if (state == AvatarState.LISTENING) {
            val progress = (time % 1.5f) / 1.5f
            val grow = progress * w * 0.12f
            rimPaint.color = withAlpha(accent, (255 * (1f - progress)).toInt())
            canvas.drawRoundRect(
                headRect.left - grow, headRect.top - grow, headRect.right + grow, headRect.bottom + grow,
                corner + grow, corner + grow, rimPaint
            )
        }

        // العينان: ترمشان، تتبعان الوجه، أو تصبحان X عند الخطأ
        updateBlink(t)
        val blinking = t < blinkUntil && !error
        val eyeY = h * 0.38f + bob
        val eyeDx = w * 0.14f
        val eyeR = w * 0.075f * (if (state == AvatarState.LISTENING) 1.2f else 1f)
        val thinkingLook = if (state == AvatarState.THINKING) sin(time * 3f) * w * 0.035f else 0f
        val lookX = gazeX * w * 0.035f + thinkingLook
        val lookY = gazeY * h * 0.02f

        if (error) {
            strokePaint.color = accent
            drawCross(canvas, w * 0.5f - eyeDx + shake, eyeY, eyeR * 0.8f)
            drawCross(canvas, w * 0.5f + eyeDx + shake, eyeY, eyeR * 0.8f)
        } else {
            val scaleY = if (blinking) 0.12f else 1f
            drawEye(canvas, w * 0.5f - eyeDx + lookX, eyeY + lookY, eyeR, scaleY, accent)
            drawEye(canvas, w * 0.5f + eyeDx + lookX, eyeY + lookY, eyeR, scaleY, accent)
        }

        drawMouth(canvas, w, h, bob, time, accent)

        if (state == AvatarState.THINKING) {
            fillPaint.color = accent
            for (i in 0..2) {
                val phase = time * 6f + i * 1.2f
                fillPaint.alpha = (140 + 115 * (0.5f + 0.5f * sin(phase))).toInt()
                canvas.drawCircle(w * 0.5f + (i - 1) * w * 0.14f, h * 0.9f + sin(phase) * h * 0.02f, w * 0.028f, fillPaint)
            }
            fillPaint.alpha = 255
        }

        spawnAccumulator += (if (state == AvatarState.READY) 3f else 22f) * dt
        while (spawnAccumulator >= 1f) {
            spawnAccumulator -= 1f
            spawnParticle()
        }
        drawParticles(canvas, dt, accent)

        if ((state == AvatarState.READY || state == AvatarState.SPEAKING) && t >= nextBoltAt) {
            createBolt(w)
            nextBoltAt = t + 2500L + random.nextInt(3000)
        }
        if (t < boltUntil) {
            boltPaint.color = withAlpha(Color.parseColor("#E0F7FA"), (255 * ((boltUntil - t).toFloat() / BOLT_MS)).toInt())
            canvas.drawPath(boltPath, boltPaint)
        }

        postInvalidateOnAnimation()
    }

    private fun accentColor(): Int = when (state) {
        AvatarState.READY -> COLOR_READY
        AvatarState.LISTENING -> COLOR_LISTENING
        AvatarState.THINKING -> COLOR_THINKING
        AvatarState.SPEAKING -> COLOR_SPEAKING
        AvatarState.ERROR -> COLOR_ERROR
    }

    private fun updateBlink(t: Long) {
        if (t >= nextBlinkAt) {
            blinkUntil = t + 130L
            nextBlinkAt = t + 2200L + random.nextInt(2600)
        }
    }

    private fun drawEye(canvas: Canvas, cx: Float, cy: Float, r: Float, scaleY: Float, accent: Int) {
        fillPaint.color = accent
        canvas.drawOval(cx - r, cy - r * scaleY, cx + r, cy + r * scaleY, fillPaint)
        if (scaleY > 0.5f) {
            fillPaint.color = Color.WHITE
            canvas.drawCircle(cx - r * 0.3f, cy - r * 0.3f, r * 0.22f, fillPaint)
        }
    }

    private fun drawCross(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        canvas.drawLine(cx - r, cy - r, cx + r, cy + r, strokePaint)
        canvas.drawLine(cx + r, cy - r, cx - r, cy + r, strokePaint)
    }

    private fun drawMouth(canvas: Canvas, w: Float, h: Float, bob: Float, time: Float, accent: Int) {
        val mouthY = h * 0.60f + bob
        val half = w * 0.09f
        val cx = w * 0.5f
        when (state) {
            AvatarState.SPEAKING -> {
                fillPaint.color = accent
                val open = (abs(sin(time * 16f)) * 0.06f + 0.012f) * h
                canvas.drawOval(cx - half, mouthY - open, cx + half, mouthY + open, fillPaint)
            }
            AvatarState.LISTENING -> {
                fillPaint.color = accent
                canvas.drawCircle(cx, mouthY, w * 0.032f, fillPaint)
            }
            AvatarState.THINKING -> {
                strokePaint.color = accent
                canvas.drawLine(cx - half * 0.7f, mouthY, cx + half * 0.7f, mouthY, strokePaint)
            }
            AvatarState.ERROR -> {
                strokePaint.color = accent
                mouthPath.reset()
                mouthPath.moveTo(cx - half, mouthY + h * 0.03f)
                mouthPath.quadTo(cx, mouthY - h * 0.03f, cx + half, mouthY + h * 0.03f)
                canvas.drawPath(mouthPath, strokePaint)
            }
            AvatarState.READY -> {
                strokePaint.color = accent
                mouthPath.reset()
                mouthPath.moveTo(cx - half, mouthY - h * 0.01f)
                mouthPath.quadTo(cx, mouthY + h * 0.05f, cx + half, mouthY - h * 0.01f)
                canvas.drawPath(mouthPath, strokePaint)
            }
        }
    }

    private fun spawnParticle() {
        if (particles.size > 60) return
        val life = 1.0f + random.nextFloat() * 1.2f
        particles.add(
            Particle(
                x = headRect.left + random.nextFloat() * headRect.width(),
                y = headRect.top + random.nextFloat() * headRect.height(),
                vx = (random.nextFloat() - 0.5f) * 30f * density,
                vy = -(15f + random.nextFloat() * 30f) * density,
                life = life,
                maxLife = life,
                radius = (1f + random.nextFloat() * 2f) * density
            )
        )
    }

    private fun drawParticles(canvas: Canvas, dt: Float, accent: Int) {
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.life -= dt
            if (p.life <= 0f) {
                iterator.remove()
                continue
            }
            p.x += p.vx * dt
            p.y += p.vy * dt
            fillPaint.color = withAlpha(accent, (255 * (p.life / p.maxLife)).toInt())
            canvas.drawCircle(p.x, p.y, p.radius, fillPaint)
        }
    }

    private fun createBolt(w: Float) {
        boltPath.reset()
        val side = if (random.nextBoolean()) 1f else -1f
        var x = if (side > 0f) headRect.right else headRect.left
        var y = headRect.top + headRect.height() * random.nextFloat()
        boltPath.moveTo(x, y)
        repeat(5) {
            x = (x + side * w * 0.035f).coerceIn(0f, w)
            y += (random.nextFloat() - 0.5f) * headRect.height() * 0.25f
            boltPath.lineTo(x, y)
        }
        boltUntil = now() + BOLT_MS
    }
}

private fun now(): Long = System.nanoTime() / 1_000_000L

private fun withAlpha(color: Int, alpha: Int): Int =
    Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
