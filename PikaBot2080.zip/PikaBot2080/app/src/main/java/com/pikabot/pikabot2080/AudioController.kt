package com.pikabot.pikabot2080

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import kotlin.math.min

// التعرف على الكلام والنطق. الميكروفون يعمل فقط بعد ضغط صريح من المستخدم
class AudioController(context: Context, private val listener: Listener) {

    interface Listener {
        fun onListeningStarted()
        fun onSpeechResult(text: String)
        fun onSpeechFailed(messageRes: Int)
        fun onSpeakingStarted()
        fun onSpeakingFinished()
    }

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val localeTags = listOf("ar-DZ", "ar-SA", "ar")
    private var localeIndex = 0
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    var isListening = false
        private set

    init {
        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            val engine = tts ?: return@TextToSpeech
            if (ttsReady) {
                val result = engine.setLanguage(Locale("ar", "DZ"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale("ar"))
                }
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        main.post { listener.onSpeakingStarted() }
                    }

                    override fun onDone(utteranceId: String?) {
                        main.post { listener.onSpeakingFinished() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { listener.onSpeakingFinished() }
                    }
                })
            }
        }
    }

    fun speak(text: String) {
        val engine = tts
        if (!ttsReady || engine == null) {
            listener.onSpeakingFinished()
            return
        }
        val clean = text.replace(Regex("[*#_`~>]+"), " ").take(3000)
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "reply-${System.nanoTime()}")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            listener.onSpeechFailed(R.string.err_speech_unavailable)
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(app)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onError(error: Int) {
                isListening = false
                if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ||
                    error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE
                ) {
                    localeIndex = min(localeIndex + 1, localeTags.lastIndex)
                }
                listener.onSpeechFailed(mapSpeechError(error))
            }

            override fun onResults(results: Bundle?) {
                isListening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (text.isNullOrEmpty()) listener.onSpeechFailed(R.string.err_no_speech)
                else listener.onSpeechResult(text)
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTags[localeIndex])
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        isListening = true
        listener.onListeningStarted()
        sr.startListening(intent)
    }

    fun stopListening() {
        recognizer?.stopListening()
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        isListening = false
    }

    private fun mapSpeechError(error: Int): Int = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> R.string.err_no_speech
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> R.string.err_language
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> R.string.err_busy
        else -> R.string.err_mic
    }
}
