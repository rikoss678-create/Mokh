package com.pikabot.pikabot2080

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// الاتصال بـ /api/chat: يرسل المحادثة ويستقبل الرد وقائمة الأوامر
class AiClient(private val endpoint: String, private val clientToken: String) {

    suspend fun ask(history: List<ChatMessage>, ctx: RequestContext): ChatResult = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("locale", "ar-DZ")
            put("messages", JSONArray().apply {
                history.forEach { put(JSONObject().put("role", it.role).put("content", it.content)) }
            })
            if (ctx.lat != null && ctx.lon != null) {
                put("location", JSONObject().put("lat", ctx.lat).put("lon", ctx.lon))
            }
        }.toString()

        val connection = URL(endpoint).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 90_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("X-Client-Token", clientToken)
            connection.setRequestProperty("X-Install-Id", ctx.installId)

            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) throw ServerException(code)

            val json = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val reply = json.optString("reply").trim()
            val actionsArray = json.optJSONArray("actions") ?: JSONArray()
            val actions = (0 until actionsArray.length()).map { i ->
                val item = actionsArray.getJSONObject(i)
                DeviceAction(item.getString("type"), item.optJSONObject("args") ?: JSONObject())
            }
            if (reply.isEmpty() && actions.isEmpty()) throw ServerException(500)
            ChatResult(reply, actions)
        } finally {
            connection.disconnect()
        }
    }
}

// ذاكرة المحادثة في الجلسة الحالية فقط (الذاكرة الدائمة على الخادم)
class ConversationManager(private val client: AiClient) {

    private val history = ArrayDeque<ChatMessage>()

    suspend fun send(userText: String, ctx: RequestContext): ChatResult {
        history.addLast(ChatMessage("user", userText.take(2000)))
        trim()
        try {
            val result = client.ask(history.toList(), ctx)
            if (result.reply.isNotEmpty()) history.addLast(ChatMessage("assistant", result.reply))
            trim()
            return result
        } catch (e: Throwable) {
            if (history.isNotEmpty() && history.last().role == "user") history.removeLast()
            throw e
        }
    }

    private fun trim() {
        while (history.size > 20) history.removeFirst()
        while (history.isNotEmpty() && history.first().role != "user") history.removeFirst()
    }
}

// /api/brief: الترحيب والطقس والتنبيهات
class BriefClient(private val url: String, private val token: String, private val installId: String) {

    suspend fun fetch(lat: Double?, lon: Double?): Brief = withContext(Dispatchers.IO) {
        val query = if (lat != null && lon != null) "?lat=$lat&lon=$lon" else ""
        val connection = URL(url + query).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("X-Client-Token", token)
            connection.setRequestProperty("X-Install-Id", installId)
            val code = connection.responseCode
            if (code !in 200..299) throw ServerException(code)
            val json = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val weather = json.optJSONObject("weather")
            val alertsArray = json.optJSONArray("alerts")
            val alerts = mutableListOf<String>()
            if (alertsArray != null) for (i in 0 until alertsArray.length()) alerts.add(alertsArray.getString(i))
            Brief(
                greeting = json.optString("greeting"),
                description = weather?.optString("description"),
                temperature = if (weather != null && weather.has("temperature")) weather.getInt("temperature") else null,
                alerts = alerts
            )
        } finally {
            connection.disconnect()
        }
    }
}

// يمسح ذاكرة الجهاز من الخادم. يجب استدعاؤه خارج الخيط الرئيسي
fun forgetServerMemory(installId: String, token: String): Boolean = try {
    val connection = URL(memoryUrl()).openConnection() as HttpURLConnection
    try {
        connection.requestMethod = "DELETE"
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("X-Client-Token", token)
        connection.setRequestProperty("X-Install-Id", installId)
        connection.responseCode in 200..299
    } finally {
        connection.disconnect()
    }
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    false
}
