package com.pikabot.pikabot2080

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ListenableWorker.Result
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

private const val ALERT_CHANNEL_ID = "pikabot_alerts"
private const val ALERT_NOTIFICATION_ID = 2081

// عمل خلفي كل 3 ساعات: يرسل إشعاراً فقط عند طقس يستحق الانتباه، ولا يكرر التنبيه نفسه
class ProactiveWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        return try {
            val loc = ctx.lastKnownLocation()
            val brief = BriefClient(briefUrl(), BuildConfig.CLIENT_TOKEN, ctx.installId())
                .fetch(loc?.latitude, loc?.longitude)
            val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val alertText = brief.alerts.joinToString("\n")
            if (alertText.isEmpty()) {
                prefs.edit().remove(KEY_LAST_ALERT).apply()
            } else if (alertText != prefs.getString(KEY_LAST_ALERT, null)) {
                prefs.edit().putString(KEY_LAST_ALERT, alertText).apply()
                showAlertNotification(ctx, alertText)
            }
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

@SuppressLint("MissingPermission")
private fun showAlertNotification(ctx: Context, text: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        !ctx.hasPermission(Manifest.permission.POST_NOTIFICATIONS)
    ) return
    ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
        NotificationChannel(ALERT_CHANNEL_ID, ctx.getString(R.string.alert_channel_name), NotificationManager.IMPORTANCE_DEFAULT)
    )
    val notification = NotificationCompat.Builder(ctx, ALERT_CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle(ctx.getString(R.string.app_name))
        .setContentText(text)
        .setStyle(NotificationCompat.BigTextStyle().bigText(text))
        .setAutoCancel(true)
        .build()
    NotificationManagerCompat.from(ctx).notify(ALERT_NOTIFICATION_ID, notification)
}

fun Context.schedulePeriodicBrief() {
    val request = PeriodicWorkRequestBuilder<ProactiveWorker>(3, TimeUnit.HOURS)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .build()
    WorkManager.getInstance(this).enqueueUniquePeriodicWork("pikabot-brief", ExistingPeriodicWorkPolicy.KEEP, request)
}
