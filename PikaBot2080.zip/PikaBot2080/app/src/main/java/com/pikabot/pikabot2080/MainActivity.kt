package com.pikabot.pikabot2080

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// شاشة الإعداد: الأذونات، تشغيل الروبوت وإيقافه، تسجيل الوجه، ومسح الذاكرة
class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var overlayButton: Button
    private lateinit var micButton: Button
    private lateinit var cameraButton: Button
    private lateinit var startButton: Button

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshUi() }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshUi() }
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshUi() }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startBotService() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildLayout())
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun buildLayout(): View {
        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        overlayButton = button(R.string.btn_grant_overlay) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        micButton = button(R.string.btn_grant_mic) { micPermission.launch(Manifest.permission.RECORD_AUDIO) }
        cameraButton = button(R.string.btn_grant_camera) { cameraPermission.launch(Manifest.permission.CAMERA) }
        val locationButton = button(R.string.btn_grant_location) {
            locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        startButton = button(R.string.btn_start) { onStartClicked() }
        val stopButton = button(R.string.btn_stop) { stopService(Intent(this, PikaBotService::class.java)) }
        val enrollButton = button(R.string.btn_enroll) { RobotEyeActivity.start(this, RobotEyeActivity.MODE_ENROLL) }
        val forgetButton = button(R.string.btn_forget_memory) {
            Thread {
                val ok = forgetServerMemory(installId(), BuildConfig.CLIENT_TOKEN)
                runOnUiThread {
                    Toast.makeText(this, if (ok) R.string.memory_forgotten else R.string.err_network, Toast.LENGTH_SHORT).show()
                }
            }.start()
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 28f
            setTextColor(Color.parseColor("#4FC3F7"))
            gravity = Gravity.CENTER
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#0B0F1E"))
            setPadding(dp(28), dp(28), dp(28), dp(28))
            addView(title)
            addView(statusText, spaced())
            listOf(overlayButton, micButton, cameraButton, locationButton, startButton, enrollButton, forgetButton, stopButton)
                .forEach { addView(it, spaced()) }
        }
    }

    private fun spaced(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }

    private fun button(labelRes: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            setText(labelRes)
            setOnClickListener { onClick() }
        }

    private fun onStartClicked() {
        if (!Settings.canDrawOverlays(this) || !hasMicPermission()) {
            refreshUi()
            return
        }
        val needsNotifications = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        if (needsNotifications) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startBotService()
    }

    private fun startBotService() {
        if (!Settings.canDrawOverlays(this) || !hasMicPermission()) return
        ContextCompat.startForegroundService(this, Intent(this, PikaBotService::class.java))
        schedulePeriodicBrief()
    }

    private fun refreshUi() {
        val overlayOk = Settings.canDrawOverlays(this)
        val micOk = hasMicPermission()
        overlayButton.visibility = if (overlayOk) View.GONE else View.VISIBLE
        micButton.visibility = if (micOk) View.GONE else View.VISIBLE
        cameraButton.visibility = if (hasCameraPermission()) View.GONE else View.VISIBLE
        startButton.isEnabled = overlayOk && micOk
        statusText.text = when {
            !overlayOk -> getString(R.string.status_overlay_missing)
            !micOk -> getString(R.string.status_mic_missing)
            else -> getString(R.string.status_ready)
        }
    }
}
