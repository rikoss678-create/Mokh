package com.pikabot.pikabot2080

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

// التعرف على الهوية: نموذج تضمين وجوه بصيغة .tflite يوضع في app/src/main/assets/.
// النموذج المقصود مفتوح المصدر: facenet_512.tflite (مشتق من deepface، إدخال 160×160، مخرج 512).
// يُجرَّب الاسم الأول ثم الثاني، ويُقرأ حجم الإدخال والمخرج من النموذج نفسه.
// بدون نموذج يتتبع الروبوت الوجه فقط ولا يعرف من هو. لا يوجد نموذج مُدمج في المشروع.
class FaceIdentity(context: Context) {

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val interpreter: Interpreter? = MODEL_ASSETS.firstNotNullOfOrNull { name ->
        try {
            val fd = app.assets.openFd(name)
            val buffer = FileInputStream(fd.fileDescriptor).channel
                .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
            Interpreter(buffer)
        } catch (e: Exception) {
            null // الملف غير موجود بهذا الاسم، نجرب التالي
        }
    }
    private val inputSize: Int = interpreter?.getInputTensor(0)?.shape()?.getOrNull(1) ?: 0

    val isModelReady: Boolean get() = interpreter != null
    val hasOwner: Boolean get() = prefs.contains(KEY_OWNER)

    // تضمين وجه: يقص الوجه إلى حجم الإدخال ويطبعه كمتجه مُطبَّع
    fun embed(face: Bitmap): FloatArray? {
        val interp = interpreter ?: return null
        val size = inputSize
        val scaled = Bitmap.createScaledBitmap(face, size, size, true)
        val pixels = IntArray(size * size)
        scaled.getPixels(pixels, 0, size, 0, 0, size, size)
        val input = ByteBuffer.allocateDirect(4 * size * size * 3).order(ByteOrder.nativeOrder())
        for (p in pixels) {
            // تطبيع [0, 1]. إن كان نموذجك يتوقع قيماً أخرى غيّر هذا السطر وفق وصف النموذج
            input.putFloat((p shr 16 and 0xFF) / 255f)
            input.putFloat((p shr 8 and 0xFF) / 255f)
            input.putFloat((p and 0xFF) / 255f)
        }
        input.rewind()
        val dim = interp.getOutputTensor(0).shape()[1]
        val output = Array(1) { FloatArray(dim) }
        interp.run(input, output)
        return normalize(output[0])
    }

    // يحفظ متوسط عينات الوجه كهوية للمالك (المستخدم نفسه)
    fun saveOwner(samples: List<FloatArray>): Boolean {
        if (samples.isEmpty()) return false
        val dim = samples[0].size
        val mean = FloatArray(dim)
        for (s in samples) for (i in 0 until dim) mean[i] += s[i] / samples.size
        prefs.edit().putString(KEY_OWNER, normalize(mean).joinToString(",")).apply()
        return true
    }

    fun clearOwner() {
        prefs.edit().remove(KEY_OWNER).apply()
    }

    fun isOwner(embedding: FloatArray): Boolean {
        val stored = prefs.getString(KEY_OWNER, null) ?: return false
        val owner = stored.split(",").map { it.toFloat() }.toFloatArray()
        if (owner.size != embedding.size) return false
        var dot = 0f
        for (i in owner.indices) dot += owner[i] * embedding[i]
        return dot >= MATCH_THRESHOLD
    }

    private fun normalize(v: FloatArray): FloatArray {
        var norm = 0f
        for (x in v) norm += x * x
        norm = sqrt(norm).coerceAtLeast(1e-6f)
        return FloatArray(v.size) { v[it] / norm }
    }

    companion object {
        private const val KEY_OWNER = "owner_embedding"
        private val MODEL_ASSETS = listOf("facenet_512.tflite", "face_embedder.tflite")
        // عتبة التشابه بين متجهين مُطبَّعين. تُعاير على نموذجك وإضاءتك (لم تُعاير بعد)
        const val MATCH_THRESHOLD = 0.6f
    }
}
