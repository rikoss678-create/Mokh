package com.pikabot.pikabot2080

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.IOException
import java.util.UUID

const val PREFS_NAME = "pikabot_prefs"
const val KEY_INSTALL_ID = "install_id"
const val KEY_LAST_ALERT = "last_alert"
const val KEY_LAST_GREETING = "last_greeting"

enum class AvatarState { READY, LISTENING, THINKING, SPEAKING, ERROR }

class ServerException(val code: Int) : IOException("HTTP $code")

data class ChatMessage(val role: String, val content: String)

// سياق كل طلب: معرّف جهاز مجهول للذاكرة، وموقع تقريبي إن توفر
data class RequestContext(val installId: String, val lat: Double?, val lon: Double?)

// أمر ينفذه الجهاز بعد رد الخادم (منبه، مؤقت، بحث، كاميرا...)
data class DeviceAction(val type: String, val args: JSONObject)

data class ChatResult(val reply: String, val actions: List<DeviceAction>)

data class Brief(
    val greeting: String,
    val description: String?,
    val temperature: Int?,
    val alerts: List<String>
)

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

fun chatUrl(): String = BuildConfig.AI_SERVER_URL
fun briefUrl(): String = BuildConfig.AI_SERVER_URL.replace("/api/chat", "/api/brief")
fun memoryUrl(): String = BuildConfig.AI_SERVER_URL.replace("/api/chat", "/api/memory")

fun Context.hasPermission(permission: String): Boolean =
    ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

fun Context.hasMicPermission(): Boolean = hasPermission(Manifest.permission.RECORD_AUDIO)
fun Context.hasCameraPermission(): Boolean = hasPermission(Manifest.permission.CAMERA)

// معرّف عشوائي يُحفظ على الجهاز؛ لا يرتبط بحساب أو رقم هاتف
fun Context.installId(): String {
    val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.getString(KEY_INSTALL_ID, null)?.let { return it }
    val id = UUID.randomUUID().toString()
    prefs.edit().putString(KEY_INSTALL_ID, id).apply()
    return id
}

// أحدث موقع تقريبي معروف، ولا يُطلب إلا إذا منح المستخدم الإذن
@SuppressLint("MissingPermission")
fun Context.lastKnownLocation(): Location? {
    if (!hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) return null
    val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    return try {
        listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)
            .mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }
            .maxByOrNull { it.time }
    } catch (e: SecurityException) {
        null
    }
}

fun Context.currentRequestContext(): RequestContext {
    val loc = lastKnownLocation()
    return RequestContext(installId(), loc?.latitude, loc?.longitude)
}
