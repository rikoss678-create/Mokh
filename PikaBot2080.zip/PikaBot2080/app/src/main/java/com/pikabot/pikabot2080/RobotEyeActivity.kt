package com.pikabot.pikabot2080

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.toBitmap
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

// شاشة عين الروبوت: الكاميرا الأمامية، تتبع الوجه، التقاط الصور، وتسجيل وجه المالك.
// تعمل فقط والشاشة مفتوحة، ولا تلتقط شيئاً في الخلفية.
class RobotEyeActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_TRACK = "track"
        const val MODE_CAPTURE = "capture"
        const val MODE_ENROLL = "enroll"
        private const val ENROLL_SAMPLES = 8
        private const val IDENTITY_INTERVAL_MS = 700L

        fun start(context: Context, mode: String) {
            context.startActivity(
                Intent(context, RobotEyeActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(EXTRA_MODE, mode)
            )
        }
    }

    private lateinit var avatar: PikaBotView
    private lateinit var statusText: TextView
    private lateinit var previewView: PreviewView
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
        .enableTracking()
        .build()
    private val detector by lazy { FaceDetection.getClient(options) }
    private val identity by lazy { FaceIdentity(this) }
    private var imageCapture: ImageCapture? = null
    private var mode = MODE_TRACK
    private var enrolling = false
    private var enrollSamples = mutableListOf<FloatArray>()
    private var lastIdentityAt = 0L
    private var captureScheduled = false

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else statusText.text = getString(R.string.err_camera)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_TRACK
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildLayout())
        if (hasCameraPermission()) startCamera() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.shutdown()
        detector.close()
    }

    private fun buildLayout(): View {
        avatar = PikaBotView(this)
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        statusText = TextView(this).apply {
            setTextColor(Color.parseColor("#4FC3F7"))
            textSize = 15f
            gravity = Gravity.CENTER
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(Button(this@RobotEyeActivity).apply {
                setText(R.string.btn_capture)
                setOnClickListener { takePhoto() }
            })
            addView(Button(this@RobotEyeActivity).apply {
                setText(R.string.btn_enroll)
                setOnClickListener { startEnrollment() }
            })
            addView(Button(this@RobotEyeActivity).apply {
                setText(R.string.btn_close)
                setOnClickListener { finish() }
            })
        }
        return FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#05070F"))
            addView(avatar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(
                previewView,
                FrameLayout.LayoutParams(dp(120), dp(160), Gravity.END or Gravity.TOP).apply {
                    topMargin = dp(56)
                    marginEnd = dp(12)
                }
            )
            addView(
                statusText,
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP)
                    .apply { topMargin = dp(16) }
            )
            addView(
                buttons,
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
                    .apply { bottomMargin = dp(24) }
            )
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(analysisExecutor) { frame -> analyze(frame) } }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageCapture, analysis)
                statusText.text = getString(R.string.camera_ready)
                if (mode == MODE_CAPTURE && !captureScheduled) {
                    captureScheduled = true
                    statusText.postDelayed({ takePhoto() }, 1500)
                }
                if (mode == MODE_ENROLL) startEnrollment()
            } catch (e: Exception) {
                statusText.text = getString(R.string.err_camera)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // يعمل على خيط التحليل: يكشف الوجه، ويحسب هويته كل بضع مئات من الميلي ثانية فقط
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        val rotation = proxy.imageInfo.rotationDegrees
        val wantIdentity = identity.isModelReady && System.currentTimeMillis() - lastIdentityAt > IDENTITY_INTERVAL_MS
        val frame = if (wantIdentity) proxy.toBitmap().rotated(rotation) else null
        val (width, height) = if (rotation == 90 || rotation == 270) {
            media.height to media.width
        } else {
            media.width to media.height
        }
        detector.process(InputImage.fromMediaImage(media, rotation))
            .addOnSuccessListener { faces -> handleFaces(faces, frame, width, height) }
            .addOnCompleteListener { proxy.close() }
    }

    // يعمل على الخيط الرئيسي (نتائج ML Kit)
    private fun handleFaces(faces: List<Face>, frame: Bitmap?, width: Int, height: Int) {
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        if (face == null) {
            avatar.setFaceVisible(false)
            avatar.setGaze(0f, 0f)
            if (!enrolling) statusText.text = getString(R.string.no_face)
            return
        }
        val box = face.boundingBox
        val nx = (box.centerX().toFloat() / width) * 2f - 1f
        val ny = (box.centerY().toFloat() / height) * 2f - 1f
        // الكاميرا الأمامية تعكس الصورة، لذلك نعكس الاتجاه أفقياً
        avatar.setGaze(-nx, ny)
        avatar.setFaceVisible(true)

        if (frame == null) return
        lastIdentityAt = System.currentTimeMillis()
        val embedding = cropFace(frame, box)?.let { identity.embed(it) } ?: return
        if (enrolling) {
            collectSample(embedding)
        } else {
            statusText.text = getString(if (identity.isOwner(embedding)) R.string.owner_face else R.string.seen_face)
        }
    }

    private fun collectSample(embedding: FloatArray) {
        enrollSamples.add(embedding)
        statusText.text = "${getString(R.string.enroll_start)} ${enrollSamples.size}/$ENROLL_SAMPLES"
        if (enrollSamples.size >= ENROLL_SAMPLES) {
            enrolling = false
            val saved = identity.saveOwner(enrollSamples)
            enrollSamples = mutableListOf()
            statusText.text = getString(if (saved) R.string.enroll_done else R.string.enroll_failed)
        }
    }

    private fun startEnrollment() {
        if (!identity.isModelReady) {
            statusText.text = getString(R.string.enroll_no_model)
            return
        }
        enrollSamples = mutableListOf()
        enrolling = true
        statusText.text = getString(R.string.enroll_start)
    }

    private fun cropFace(frame: Bitmap, box: Rect): Bitmap? {
        val margin = (box.width() * 0.15f).toInt()
        val left = (box.left - margin).coerceAtLeast(0)
        val top = (box.top - margin).coerceAtLeast(0)
        val right = (box.right + margin).coerceAtMost(frame.width)
        val bottom = (box.bottom + margin).coerceAtMost(frame.height)
        val w = right - left
        val h = bottom - top
        if (w <= 10 || h <= 10) return null
        return Bitmap.createBitmap(frame, left, top, w, h)
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "pikabot_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PikaBot")
            }
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                statusText.text = getString(R.string.photo_saved)
                if (mode == MODE_CAPTURE) statusText.postDelayed({ finish() }, 2500)
            }

            override fun onError(exception: ImageCaptureException) {
                statusText.text = getString(R.string.photo_failed)
            }
        })
    }

    private fun Bitmap.rotated(degrees: Int): Bitmap {
        if (degrees == 0) return this
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
    }
}
