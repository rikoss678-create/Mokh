package com.pikabot.pikabot2080

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val CHANNEL_ID = "pikabot_foreground"
private const val NOTIFICATION_ID = 2080
private const val ACTION_STOP = "com.pikabot.pikabot2080.action.STOP"
private const val GREETING_GAP_MS = 2 * 60 * 60 * 1000L

// الروبوت العائم بلا أي لوحة كتابة: يتحدث ويستمع بالضغط عليه، ويعرض ردوده فقط كتسمية قصيرة
class PikaBotService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var layoutParams: WindowManager.LayoutParams
    private lateinit var conversation: ConversationManager
    private lateinit var audio: AudioController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private var root: LinearLayout? = null
    private var avatar: PikaBotView? = null
    private var caption: TextView? = null
    private var busy = false

    private val hideCaption = Runnable { caption?.visibility = View.GONE }

    private val audioListener = object : AudioController.Listener {
        override fun onListeningStarted() {
            setState(AvatarState.LISTENING)
            showCaption(getString(R.string.state_listening), 0)
        }

        override fun onSpeechResult(text: String) {
            ask(text)
        }

        override fun onSpeechFailed(messageRes: Int) {
            showCaption(getString(messageRes), 3000)
            setState(AvatarState.READY)
        }

        override fun onSpeakingStarted() = setState(AvatarState.SPEAKING)

        override fun onSpeakingFinished() {
            if (avatar?.state == AvatarState.SPEAKING) setState(AvatarState.READY)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        conversation = ConversationManager(AiClient(chatUrl(), BuildConfig.CLIENT_TOKEN))
        audio = AudioController(this, audioListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // نعلن الخدمة أمامية فوراً، لأن Android 12+ يعاقب الخدمة التي تتوقف دون ذلك
        startForegroundCompat()
        if (!Settings.canDrawOverlays(this) || !hasMicPermission()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) {
            buildOverlay()
            greetIfDue()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        audio.release()
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        avatar = null
        caption = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val channel = NotificationChannel(
            CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, PikaBotService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openApp)
            .addAction(0, getString(R.string.btn_stop), stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        // نوع الخدمة الأمامية: الميكروفون، وهو مصرّح به في البيان
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    private fun buildOverlay() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        caption = TextView(this).apply {
            setTextColor(Color.parseColor("#E0F7FA"))
            textSize = 14f
            gravity = Gravity.CENTER
            maxWidth = dp(260)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.argb(170, 10, 14, 30))
                setStroke(dp(1), Color.argb(150, 79, 195, 247))
            }
            visibility = View.GONE
        }
        val avatarView = PikaBotView(this).apply { setOnTouchListener(buildTouchListener()) }
        avatar = avatarView

        container.addView(caption, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(6)
        })
        container.addView(avatarView, LinearLayout.LayoutParams(dp(150), dp(150)))

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(200)
        }
        root = container
        windowManager.addView(container, layoutParams)
    }

    // السحب إلى أي مكان؛ النقرة القصيرة تبدأ الاستماع أو توقفه
    private fun buildTouchListener(): View.OnTouchListener {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        return View.OnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = layoutParams.x
                    startY = layoutParams.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) moveTo(startX + dx.toInt(), startY + dy.toInt())
                }
                MotionEvent.ACTION_UP -> if (!dragging) onAvatarTapped()
            }
            true
        }
    }

    private fun moveTo(x: Int, y: Int) {
        val r = root ?: return
        val metrics = resources.displayMetrics
        layoutParams.x = x.coerceIn(0, maxOf(0, metrics.widthPixels - r.width))
        layoutParams.y = y.coerceIn(0, maxOf(0, metrics.heightPixels - r.height))
        windowManager.updateViewLayout(r, layoutParams)
    }

    private fun onAvatarTapped() {
        if (!hasMicPermission()) {
            showCaption(getString(R.string.err_mic), 3000)
            return
        }
        if (audio.isListening) {
            audio.stopListening()
            return
        }
        if (busy) {
            showCaption(getString(R.string.err_busy), 2500)
            return
        }
        audio.startListening()
    }

    // إرسال الكلام إلى الخادم، ثم النطق، ثم تنفيذ الأوامر على الجهاز
    private fun ask(text: String) {
        if (busy) return
        busy = true
        setState(AvatarState.THINKING)
        showCaption(text, 0)
        scope.launch {
            try {
                val result = conversation.send(text, currentRequestContext())
                val reply = result.reply.ifEmpty { getString(R.string.action_done) }
                showCaption(reply, 9000)
                setState(AvatarState.SPEAKING)
                audio.speak(reply)
                result.actions.forEach { ActionExecutor.execute(this@PikaBotService, it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ServerException) {
                fail(R.string.err_server)
            } catch (e: Exception) {
                fail(R.string.err_network)
            } finally {
                busy = false
            }
        }
    }

    // ترحيب تلقائي عند التشغيل، مرة كل ساعتين على الأكثر، حسب الوقت والطقس الحقيقيين
    private fun greetIfDue() {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong(KEY_LAST_GREETING, 0L) < GREETING_GAP_MS) return
        prefs.edit().putLong(KEY_LAST_GREETING, now).apply()
        scope.launch {
            val brief: Brief = try {
                val loc = lastKnownLocation()
                BriefClient(briefUrl(), BuildConfig.CLIENT_TOKEN, installId()).fetch(loc?.latitude, loc?.longitude)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return@launch
            }
            val opening = brief.greeting.ifEmpty { "مرحبا" }
            val weather = brief.temperature?.let { " الطقس: ${brief.description ?: ""} ${it}°." } ?: ""
            val text = "$opening!$weather"
            showCaption(text, 9000)
            setState(AvatarState.SPEAKING)
            audio.speak(text)
            brief.alerts.firstOrNull()?.let { showCaption(it, 12000) }
        }
    }

    private fun fail(messageRes: Int) {
        showCaption(getString(messageRes), 5000)
        setState(AvatarState.ERROR)
        handler.postDelayed({ if (avatar?.state == AvatarState.ERROR) setState(AvatarState.READY) }, 3000)
    }

    private fun setState(state: AvatarState) {
        avatar?.state = state
    }

    // hideAfterMs = 0 يعني أن التسمية تبقى حتى تُستبدل
    private fun showCaption(text: String, hideAfterMs: Long) {
        val view = caption ?: return
        handler.removeCallbacks(hideCaption)
        view.text = text
        view.visibility = View.VISIBLE
        if (hideAfterMs > 0) handler.postDelayed(hideCaption, hideAfterMs)
    }
}
