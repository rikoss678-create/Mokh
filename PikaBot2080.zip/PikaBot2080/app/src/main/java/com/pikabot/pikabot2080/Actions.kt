package com.pikabot.pikabot2080

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import java.net.URLEncoder

// ينفذ الأوامر التي يرسلها الخادم، باستخدام تطبيقات الهاتف الحقيقية
object ActionExecutor {

    fun execute(context: Context, action: DeviceAction) {
        val args = action.args
        when (action.type) {
            "set_alarm" -> startSafely(
                context,
                Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, args.optInt("hour"))
                    putExtra(AlarmClock.EXTRA_MINUTES, args.optInt("minute"))
                    putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "PikaBot"))
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                }
            )
            "set_timer" -> startSafely(
                context,
                Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, args.optInt("seconds"))
                    putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "PikaBot"))
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                }
            )
            "open_google_search" -> {
                val query = URLEncoder.encode(args.optString("query"), "UTF-8")
                startSafely(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$query")))
            }
            "take_photo" -> RobotEyeActivity.start(context, RobotEyeActivity.MODE_CAPTURE)
            "track_face" -> RobotEyeActivity.start(context, RobotEyeActivity.MODE_TRACK)
        }
    }

    private fun startSafely(context: Context, intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            // لا يوجد تطبيق يعالج هذا الأمر على الجهاز
        }
    }
}
